# NEXUS VR

A two-part, Quest 3S-focused device management project.

## Projects
- `desktop/`: WPF desktop manager targeting .NET Framework 4.8. Designed for Windows 7 SP1 x64 and newer. Uses external ADB executable.
- `standalone/`: Native Android/Quest companion APK starter. It can show device/app information and open Android's package installer for APKs selected by the user. It does **not** claim privileged system-wide ADB access.

## Important limitations
- The desktop app can use ADB only after the Quest has Developer Mode enabled, USB debugging has been authorized, and the appropriate Oculus USB driver is installed.
- Quest 3S refresh-rate choices depend on runtime/device support. Common rates are 72/80/90/120 Hz; 96/100 Hz are runtime/display dependent.
- ADB `setprop` changes are developer controls and may reset after reboot or be ignored by particular OS versions.
- FFR is not a universal system-wide switch for third-party apps. This starter exposes a safe command panel and does not pretend every headset firmware accepts every property.
- The standalone app cannot run ADB against its own host OS or grant itself privileged permissions. APK installation is delegated to Android's package installer and may require user confirmation.

## Build desktop
Open `desktop/NexusVR.sln` in Visual Studio 2019 with .NET Framework 4.8 targeting pack installed. Build `Release | x64`.
The GitHub Actions workflow in `.github/workflows/build-desktop.yml` also builds the desktop project and publishes the output artifact.

For Windows 7, install Windows 7 SP1 and the required servicing updates, .NET Framework 4.8, and a supported graphics driver. The app is not digitally signed in this starter.

## Build standalone APK
Open `standalone/` in Android Studio with JDK 17 and Android SDK installed. Build > Build APK(s).
The app targets Quest 3S in its manifest. Install the APK through the desktop app's APK sideloading tab or Meta's developer tooling.

## ADB
Put `adb.exe`, `AdbWinApi.dll`, and `AdbWinUsbApi.dll` in `desktop/Tools/platform-tools/`, or use Settings to browse to an existing ADB executable. Do not download executables from untrusted mirrors. Google Platform Tools: https://developer.android.com/tools/releases/platform-tools
Meta Oculus ADB driver: https://developer.oculus.com/downloads/package/oculus-adb-drivers/

## Current implementation status
This is a buildable foundation, not a feature-complete SideQuest replacement. It includes a desktop shell, device detection, ADB command execution, APK install, device info, refresh-rate presets, graphics property controls, safe FFR command templates, and a native Quest companion starter. More advanced features require testing against the exact Quest OS firmware.
