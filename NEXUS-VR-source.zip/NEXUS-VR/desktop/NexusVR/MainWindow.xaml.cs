using Microsoft.Win32;
using NexusVR.Services;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NexusVR
{
    public partial class MainWindow : Window
    {
        private readonly AdbService adb = new AdbService();
        public MainWindow() { InitializeComponent(); }

        private void Log(string value)
        {
            Output.AppendText(Environment.NewLine + "[" + DateTime.Now.ToString("HH:mm:ss") + "] " + value);
            Output.ScrollToEnd();
        }

        private async void Refresh_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string devices = await adb.Run("devices");
                Log("adb devices: " + devices);
                bool online = devices.Contains("\tdevice");
                StatusDot.Fill = online ? new SolidColorBrush(Color.FromRgb(99,217,209)) : new SolidColorBrush(Color.FromRgb(217,154,87));
                ConnectionText.Text = online ? "ADB device detected" : "No authorized device";
                AdbStatus.Text = online ? "Connected" : "Waiting";
                if (online)
                {
                    string model = await adb.Run("shell getprop ro.product.model");
                    string android = await adb.Run("shell getprop ro.build.version.release");
                    DeviceName.Text = model.Trim().Length == 0 ? "Android device" : model.Trim();
                    DeviceDetails.Text = "Android " + android.Trim() + " • Verify the model before applying device-specific tweaks.";
                }
            }
            catch (Exception ex) { Log("ADB error: " + ex.Message); }
        }

        private async void Nav_Click(object sender, RoutedEventArgs e)
        {
            string page = (string)((Button)sender).Tag;
            PageTitle.Text = page;
            if (page == "Overview") return;
            if (page == "Graphics")
            {
                Log("Graphics presets use Meta developer properties. Changes may reset after reboot.");
                Log("Quest 3S defaults: texture width 1680, texture height 1760.");
                Log("Use ADB terminal for custom values; confirm firmware support first.");
            }
            else if (page == "Refresh rate")
            {
                Log("Quest 3S supported common rates: 72, 80, 90, 120 Hz. 96/100 Hz are runtime/display dependent.");
                Log("Choose a preset only after the device is connected.");
                var result = MessageBox.Show("Apply 90 Hz to the connected device? This uses a developer system property and may be ignored or reset by firmware.", "NEXUS VR", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Yes) Log(await adb.Run("shell setprop debug.oculus.refreshRate 90"));
            }
            else if (page == "ADB terminal")
            {
                string command = Microsoft.VisualBasic.Interaction.InputBox("Enter ADB arguments (example: shell getprop ro.product.model)", "ADB terminal", "devices");
                if (!String.IsNullOrWhiteSpace(command)) Log(await adb.Run(command));
            }
            else if (page == "APK sideloading")
            {
                var dialog = new OpenFileDialog { Filter = "Android package (*.apk)|*.apk", Title = "Select APK to install" };
                if (dialog.ShowDialog() == true) Log(await adb.Run("install -r \"" + dialog.FileName + "\""));
            }
            else if (page == "FFR")
            {
                Log("FFR is not a universal system-wide Quest switch. Per-app foveation depends on the app/runtime API.");
                Log("No unsafe or undocumented global toggle is applied by this starter.");
            }
            else if (page == "Files & backups")
            {
                Log("Use ADB pull/push through the terminal. Full app-data backup may be restricted by Android.");
            }
            else if (page == "Settings")
            {
                var dialog = new OpenFileDialog { Filter = "ADB executable (adb.exe)|adb.exe", Title = "Locate adb.exe" };
                if (dialog.ShowDialog() == true) { adb.AdbPath = dialog.FileName; Log("ADB path set to " + adb.AdbPath); }
            }
        }
    }
}
