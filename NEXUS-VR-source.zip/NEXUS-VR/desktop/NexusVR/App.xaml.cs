using System.Windows;
namespace NexusVR { public partial class App : Application { } }
