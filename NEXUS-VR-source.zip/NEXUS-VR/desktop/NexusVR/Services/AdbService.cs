using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace NexusVR.Services
{
    public class AdbService
    {
        public string AdbPath { get; set; }

        public AdbService()
        {
            string local = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Tools", "platform-tools", "adb.exe");
            AdbPath = File.Exists(local) ? local : "adb.exe";
        }

        public async Task<string> Run(string arguments)
        {
            return await Task.Run(() =>
            {
                var psi = new ProcessStartInfo
                {
                    FileName = AdbPath,
                    Arguments = arguments,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    WorkingDirectory = Path.GetDirectoryName(AdbPath) ?? AppDomain.CurrentDomain.BaseDirectory
                };
                using (var p = Process.Start(psi))
                {
                    string stdout = p.StandardOutput.ReadToEnd();
                    string stderr = p.StandardError.ReadToEnd();
                    p.WaitForExit();
                    return (stdout + Environment.NewLine + stderr).Trim();
                }
            });
        }

        public async Task<bool> IsQuest3S()
        {
            string model = await Run("shell getprop ro.product.model");
            string product = await Run("shell getprop ro.product.device");
            string combined = (model + " " + product).ToLowerInvariant();
            return combined.Contains("quest") || combined.Contains("hollywood");
        }
    }
}
