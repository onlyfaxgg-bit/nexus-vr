# NEXUS VR Standalone

Native Android starter targeting Meta Quest 3S (`quest3s` manifest metadata).

Build with Android Studio, JDK 17, Android Gradle Plugin 8.5.2, and Android SDK 35.

This is a standalone companion UI, not a privileged device manager. Android apps cannot grant themselves ADB shell/root permissions. APK selection delegates to the OS package installer and user confirmation. Global graphics, FFR, and refresh controls are not promised from this app; use supported OpenXR app-level APIs or desktop ADB where permitted.
