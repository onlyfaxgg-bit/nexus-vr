package com.nexusvr.standalone

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 20, 27)
    private val panel = Color.rgb(27, 35, 45)
    private val mint = Color.rgb(99, 217, 209)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(bg)
            setPadding(28, 24, 28, 24)
        }
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            background = rounded(panel, 18)
        }
        val brand = TextView(this).apply {
            text = "NEXUS\nVR"
            textSize = 27f
            setTextColor(mint)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(12, 12, 12, 28)
        }
        nav.addView(brand)
        listOf("Overview", "APK library", "Display", "Performance", "About").forEach { item ->
            val b = Button(this).apply {
                text = item
                isAllCaps = false
                setTextColor(Color.WHITE)
                setOnClickListener { when(item) {
                    "APK library" -> pickApk()
                    "Display" -> showDisplay()
                    "Performance" -> showPerformance()
                    "About" -> showAbout()
                    else -> showHome()
                } }
            }
            nav.addView(b)
        }
        root.addView(nav, LinearLayout.LayoutParams(230, ViewGroup.LayoutParams.MATCH_PARENT))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 12, 12, 12)
        }
        root.addView(content, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        return root
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun heading(title: String, subtitle: String) {
        content.removeAllViews()
        content.addView(TextView(this).apply {
            text = title; textSize = 29f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        content.addView(TextView(this).apply {
            text = subtitle; textSize = 14f; setTextColor(Color.LTGRAY)
            setPadding(0, 6, 0, 24)
        })
    }

    private fun card(title: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 16f)
            setPadding(20, 16, 20, 16)
        }
        box.addView(TextView(this).apply { text = title; textSize = 18f; setTextColor(mint); typeface = Typeface.DEFAULT_BOLD })
        box.addView(TextView(this).apply { text = body; textSize = 14f; setTextColor(Color.WHITE); setPadding(0, 8, 0, 0) })
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = 14
        content.addView(box, lp)
    }

    private fun showHome() {
        setContentView(base())
        heading("Headset workspace", "Standalone companion • Quest 3S profile")
        card("NEXUS VR", "A lightweight headset-native companion. Some advanced controls require a connected computer and ADB.")
        card("Device", "This app is running directly on your Quest. Android restricts ordinary apps from executing privileged ADB commands against their own host system.")
        card("Quick actions", "Open APK library to select an APK and pass it to Android's package installer.")
    }

    private fun showDisplay() {
        if (!::content.isInitialized) { showHome(); return }
        heading("Display", "Runtime-controlled display modes")
        card("Quest 3S refresh rates", "Common supported modes: 72, 80, 90 and 120 Hz. 96/100 Hz depend on runtime and display enumeration.")
        card("Important", "This companion cannot force a global headset refresh rate from an ordinary Android app. Use the desktop ADB tool or a supported app-level XR API.")
    }

    private fun showPerformance() {
        if (!::content.isInitialized) { showHome(); return }
        heading("Performance", "Safe monitoring and guidance")
        card("Thermals & frame pacing", "System-wide performance telemetry is restricted. Use Meta's OVR Metrics Tool or supported developer tooling for authoritative headset metrics.")
        card("Foveated rendering", "FFR is normally configured by the XR application through supported runtime extensions, not as a universal global switch.")
    }

    private fun showAbout() {
        if (!::content.isInitialized) { showHome(); return }
        heading("About NEXUS", "NEXUS VR Standalone 0.1.0")
        card("Designed for Quest 3S", "Native Android companion starter. No root, hidden APIs, or privileged permissions are assumed.")
    }

    private fun pickApk() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.android.package-archive"
        }
        startActivityForResult(intent, 42)
    }

    @Deprecated("Use Activity Result APIs in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            val install = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try { startActivity(install) }
            catch (_: Exception) { Toast.makeText(this, "Package installer unavailable for this APK.", Toast.LENGTH_LONG).show() }
        }
    }
}
